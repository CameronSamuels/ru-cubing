// ===== Helper Functions ===== //
function id(what) { return document.getElementById(what) }
function get(what) { return localStorage[what] }

// ===== Timing Functions ===== //
var timer = {};
timer.time = 0;
timer.run = 'false';
timer.base = 0;
timer.toggle = function() {
	if (timer.run == 'false') {
        if (id('timer').style.color == "rgb(127, 255, 0)") {
    		timer.time = 0;
    		timer.base = new Date();
    		timer.run = 'true';
    		id('timer').style.color = '#7FFF00';
        }
	}
	else if (timer.run == 'true') {
		timer.run = 'false';
		id('timer').style.color = '#FFF';
		id('scramble').innerHTML = generateScramble();
	}
};
timer.tick = function() {
	if (timer.run == 'true') {
		timer.time = new Date() - timer.base;
		id('timer').innerHTML = timer.format(timer.time);
		document.title = timer.format(timer.time) + ' - RU Cubing';
	}
	window.requestAnimationFrame(timer.tick);
};
timer.format = function(time) {
	var ms = time.toString().substring(time.toString().length - 3, time.toString().length);
	var h = Math.floor(time / 3600000);
	var m = Math.floor(time / 60000) - (h * 3600);
	var s = Math.floor(time / 1000) - (m * 60);
	time = '';
	if (h >= 1) { time = h + ':' }
	if (m >= 1) { time += m + ':' }
	for (i = 0; i < (2 - s.toString().length); i++) { s = '0' + s; }
	time += s + ':';
	for (i = 0; i < (3 - ms.length); i++) { ms = '0' + ms; }
	time += ms;
	return time;
};

function generateNotation() {
	var notation = Math.floor(Math.random() * 6);
    switch (notation) {
        case 0: notation = "U"; break;
        case 1: notation = "D"; break;
        case 2: notation = "F"; break;
        case 3: notation = "B"; break;
        case 4: notation = "L"; break;
        case 5: notation = "R"; break;
        default: notation = "U";
    }
    var addOn = Math.floor(Math.random() * 6);
    if (addOn == 3 || addOn == 4) {
        notation += "i";
    } else if (addOn == 5) {
        notation += "2";
    }
    return notation;
}

function generateScramble() {
	var scramble = '';
    var notation = "U", notation2;
    for (i = 0; i < 25; i++) {
        notation2 = notation;
        notation = generateNotation();
        while (notation.charAt(0) == notation2.charAt(0) || notation2.charAt(0) == notation.charAt(0)) {
            notation = generateNotation();
        }
        scramble += notation + " ";
    }
    return scramble;
}

// ===== Keyboard Events ===== //
var keyDown = 'false';
id('body').onkeyup = function (e) {     
    if (e.keyCode == 32) {
        timer.toggle();
        id('timer').style.color = "#FFFFFF";
        keyDown = 'false';
    }
};
id('body').onkeydown = function (e) {
    if (keyDown == 'false') {
        if (e.keyCode == 32) {
            id('timer').style.color = "#FF0000";
            keyDown = 'true';
            setTimeout(function(){if (keyDown == 'true'){id('timer').style.color = "#7FFF00";}}, 500);
        }
    }
};
id('body').onmouseup = function (e) {     
        timer.toggle();
        id('timer').style.color = "#FFFFFF";
        keyDown = 'false';
};
id('body').onmousedown = function (e) {
    if (keyDown == 'false') {
            id('timer').style.color = "#FF0000";
            keyDown = 'true';
            setTimeout(function(){if (keyDown == 'true'){id('timer').style.color = "#7FFF00";}}, 500);
    }
};

// ===== Initilize ===== //
id('scramble').innerHTML = generateScramble();
timer.tick();

document.addEventListener('DOMContentLoaded', function () {
  document.querySelector('body').addEventListener('onmouseup', function(){timer.toggle()});
});